/*
 * @Author: bucai
 * @Date: 2020-05-05 10:54:31
 * @LastEditors: bucai
 * @LastEditTime: 2020-05-05 11:00:30
 * @Description: 文件
 */
import Vue from 'vue';
import * as file from '../utils/file';

Vue.prototype.$file = file;
