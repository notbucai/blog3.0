/*
 * @Author: bucai
 * @Date: 2020-06-02 14:47:53
 * @LastEditors: bucai
 * @LastEditTime: 2020-06-02 14:48:30
 * @Description: 
 */ 
import Vue from 'vue';
const vueCropper = require('vue-cropper')
Vue.use(vueCropper.default)
