/*
 * @Author: bucai
 * @Date: 2020-04-19 23:12:32
 * @LastEditors: bucai
 * @LastEditTime: 2020-04-19 23:14:03
 * @Description: 
 */
import Vue from 'vue';
import * as dom from '../assets/dom';

Vue.prototype.$dom = dom;

