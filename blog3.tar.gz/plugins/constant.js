/*
 * @Author: bucai
 * @Date: 2020-05-02 22:03:18
 * @LastEditors: bucai
 * @LastEditTime: 2020-05-03 11:39:51
 * @Description: 
 */
import Vue from 'vue';
import * as constant from '../constant/common';

Vue.$constant = Vue.prototype.$constant = constant;