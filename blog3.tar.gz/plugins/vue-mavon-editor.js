/*
 * @Author: bucai
 * @Date: 2020-05-04 20:42:44
 * @LastEditors: bucai
 * @LastEditTime: 2020-05-06 16:29:13
 * @Description: 
 */

import Vue from 'vue';
import mavonEditor from 'mavon-editor';
import 'mavon-editor/dist/css/index.css';

Vue.use(mavonEditor);
